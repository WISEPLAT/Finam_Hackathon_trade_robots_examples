class Config:

    TELEGRAM_TOKEN = 'XXX' #токен чат бота от BotFather
    ADMIN_USER_NAME = 'XXX' #управление ботом только от админа username в тг без @
    CHAT_ID = 'XXX' #id кому отправлять сообщения


    ClientIds = ('XXX',)  # Торговые счёта Finam
    AccessToken = 'XXX'  # Торговый токен доступа Common


    FilePath = '/home/trading_bot/Data/' # Путь для сохранения скопированных данных от export.finam.ru и log.log
    #FilePath = 'D:\трейдинг\AlgoTrading\Hackathon\Data\\' # Путь для сохранения скопированных данных от export.finam.ru и log.log