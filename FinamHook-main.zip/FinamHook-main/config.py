TELEGRAM_API_TOKEN = ""
FINAM_API_TOKEN = ""
CHAT_ID = 
CLIENT_ID = ""
FINAM_API_BASE_URL = "https://trade-api.finam.ru"
IP_SERVER="localhost"
