from Telegram.telegram_bot import start_bot
# Запуск бота
if __name__ == "__main__":
    start_bot()