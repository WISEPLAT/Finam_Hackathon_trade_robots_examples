install.packages("rusquant",repos = "https://cloud.r-project.org/")
