import React from 'react';
import './App.css';
import InfoBar from './components/InfoBar/InfoBar';


function App() {
  return (
    <div>
      <InfoBar></InfoBar>
    </div>
  )
}

export default App;