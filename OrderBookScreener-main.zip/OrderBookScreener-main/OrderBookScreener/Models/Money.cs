﻿namespace OrderBookScreener
{
    /// <summary>Деньги</summary>
    public class Money
    {
        /// <summary>Валюта</summary>
        public string Currency { get; set; }

        /// <summary>Баланс</summary>
        public double Balance { get; set; }
    }
}
