package com.mycompany.finamhackaton

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
